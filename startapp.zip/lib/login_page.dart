import 'package:flutter/material.dart';

import 'api_service.dart';

import 'register_page.dart';
import 'forgotten_password.dart';
import 'home_page.dart';
import 'two_factor_page.dart';
import 'notification_service.dart';

import 'socket_service.dart';

import 'package:google_sign_in/google_sign_in.dart';

import 'package:flutter_login_facebook/flutter_login_facebook.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _formKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();

  bool _obscurePassword = true;
  bool _isLoading = false;

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  String? _validateEmail(String? value) {
    if (value == null || value.isEmpty) {
      return 'Please enter your email';
    }
    final emailRegex = RegExp(r'^[^@]+@[^@]+\.[^@]+');
    if (!emailRegex.hasMatch(value)) {
      return 'Please enter a valid email address';
    }
    return null;
  }

  String? _validatePassword(String? value) {
    if (value == null || value.isEmpty) {
      return 'Please enter your password';
    }
    if (value.length < 6) {
      return 'Password must be at least 6 characters long';
    }
    return null;
  }

  Future<void> _handleLogin() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);

    try {
      final data = await ApiService.login(
        email: _emailController.text.trim(),
        password: _passwordController.text,
      );

      await NotificationService.instance.registerCurrentTokenWithBackend();

      if (!mounted) return;

      if (data['requiresTwoFactor'] == true) {
        // navighează spre ecranul de introducere cod 2FA
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => TwoFactorPage(userId: data['userId']),
          ),
        );
      } else {
        // JWT-ul este deja salvat de ApiService.login().
        // Acum asociem tokenul FCM cu utilizatorul autentificat.
        final fcmToken = await NotificationService.instance.getToken();

        if (fcmToken != null && fcmToken.isNotEmpty) {
          await NotificationService.instance.registerTokenWithBackend(fcmToken);
        }

        await SocketService.connect();

        if (!mounted) return;

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const HomePage()),
        );
      }
    } on ApiException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(e.message)));
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Eroare de conexiune: $e')));
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _handleGoogleSignIn() async {
    setState(() => _isLoading = true);

    try {
      final GoogleSignIn googleSignIn = GoogleSignIn(
        serverClientId: '704537003987-nhbquge06mbasglpsush74qpj8a42t1n.apps.googleusercontent.com',
      );

      final googleUser = await googleSignIn.signIn();

      if (googleUser == null) {
        return;
      }

      final googleAuth = await googleUser.authentication;

      final idToken = googleAuth.idToken;

      if (idToken == null || idToken.isEmpty) {
        throw Exception('Google nu a returnat ID token.');
      }

      debugPrint('GOOGLE ID TOKEN primit');

      final data = await ApiService.googleLogin(idToken);

      debugPrint('GOOGLE NEXORA LOGIN: $data');

      await NotificationService.instance.registerCurrentTokenWithBackend();

      await SocketService.connect();

      if (!mounted) return;

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const HomePage()),
      );
    } on ApiException catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(e.message)));
    } catch (e) {
      debugPrint('GOOGLE LOGIN ERROR: $e');

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Eroare la autentificarea cu Google: $e')),
      );
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  Future<void> _handleFacebookSignIn() async {
    setState(() => _isLoading = true);

    try {
      final facebookLogin = FacebookLogin();

      final result = await facebookLogin.logIn(
        permissions: [
          FacebookPermission.publicProfile,
          FacebookPermission.email,
        ],
      );

      await NotificationService.instance.registerCurrentTokenWithBackend();

      if (result.status != FacebookLoginStatus.success) {
        if (result.status == FacebookLoginStatus.cancel) {
          debugPrint('FACEBOOK: user a anulat autentificarea');
        } else {
          debugPrint('FACEBOOK: autentificarea a eșuat: ${result.status}');
        }

        return;
      }

      final accessToken = await facebookLogin.accessToken;

      if (accessToken == null) {
        throw Exception('Lipsește token-ul de acces Facebook');
      }

      final tokenString = accessToken.token;

      debugPrint('FACEBOOK: accessToken = $tokenString');

      // Datele utilizatorului Facebook
      final profile = await facebookLogin.getUserProfile();

      debugPrint('FACEBOOK USER ID: ${profile?.userId}');

      debugPrint('FACEBOOK USER NAME: ${profile?.name}');

      // Login pe backend-ul Nexora
      final backendResult = await ApiService.facebookLogin(tokenString);

      debugPrint('FACEBOOK BACKEND: login OK');

      debugPrint(
        'FACEBOOK BACKEND: '
        '${backendResult['user'] ?? backendResult}',
      );

      // VERIFICĂM CE RETURNĂ /me
      final currentUser = await ApiService.getCurrentUser();

      debugPrint(
        'CURRENT USER AFTER FACEBOOK LOGIN: '
        '$currentUser',
      );

      // JWT-ul este acum salvat.
      // Înregistrăm token-ul FCM pentru utilizator.
      final fcmToken = await NotificationService.instance.getToken();

      if (fcmToken != null && fcmToken.isNotEmpty) {
        await NotificationService.instance.registerTokenWithBackend(fcmToken);
      }

      // Conectăm Socket.IO după autentificare.
      await SocketService.connect();

      if (!mounted) {
        return;
      }

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const HomePage()),
      );
    } catch (e) {
      debugPrint('FACEBOOK LOGIN ERROR: $e');

      if (!mounted) {
        return;
      }

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Eroare la autentificarea cu Facebook: $e')),
      );
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
        title: const Text(
          'Login',
          style: TextStyle(fontWeight: FontWeight.w700),
        ),
        centerTitle: false,
      ),
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Form(
              key: _formKey,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Icon(
                    Icons.lock_outline,
                    size: 72,
                    color: Colors.deepPurple,
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'Bine ai revenit',
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.headlineMedium
                        ?.copyWith(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Conectează-te la contul tău',
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.bodyMedium
                        ?.copyWith(color: Colors.grey[600]),
                  ),
                  const SizedBox(height: 32),

                  // Email
                  TextFormField(
                    controller: _emailController,
                    keyboardType: TextInputType.emailAddress,
                    validator: _validateEmail,
                    decoration: const InputDecoration(
                      labelText: 'Email',
                      prefixIcon: Icon(Icons.email_outlined),
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Parolă
                  TextFormField(
                    controller: _passwordController,
                    obscureText: _obscurePassword,
                    validator: _validatePassword,
                    decoration: InputDecoration(
                      labelText: 'Parolă',
                      prefixIcon: const Icon(Icons.lock_outline),
                      border: const OutlineInputBorder(),
                      suffixIcon: IconButton(
                        icon: Icon(
                          _obscurePassword
                              ? Icons.visibility_outlined
                              : Icons.visibility_off_outlined,
                        ),
                        onPressed: () {
                          setState(() => _obscurePassword = !_obscurePassword);
                        },
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),

                  Align(
                    alignment: Alignment.centerRight,
                    child: TextButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const ForgottenPassword(),
                          ),
                        );
                      },
                      child: const Text('Ai uitat parola?'),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Buton login
                  FilledButton(
                    onPressed: _isLoading ? null : _handleLogin,
                    style: FilledButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 16),
                    ),
                    child: _isLoading
                        ? const SizedBox(
                            height: 20,
                            width: 20,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.white,
                            ),
                          )
                        : const Text('Autentificare'),
                  ),
                  const SizedBox(height: 16),

                  // Buton Google
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(child: Divider(color: Colors.grey[300])),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        child: Text(
                          'sau',
                          style: TextStyle(color: Colors.grey[600]),
                        ),
                      ),
                      Expanded(child: Divider(color: Colors.grey[300])),
                    ],
                  ),
                  const SizedBox(height: 16),
                  OutlinedButton.icon(
                    onPressed: _isLoading ? null : _handleGoogleSignIn,
                    icon: Image.network(
                      'https://www.google.com/favicon.ico',
                      height: 20,
                      width: 20,
                    ),
                    label: const Text('Continuă cu Google'),
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      side: BorderSide(color: Colors.grey[300]!),
                    ),
                  ),

                  // Buton Facebook
                  const SizedBox(height: 8),
                  OutlinedButton.icon(
                    onPressed: _isLoading ? null : _handleFacebookSignIn,
                    icon: Image.network(
                      'https://www.facebook.com/favicon.ico',
                      height: 20,
                      width: 20,
                    ),
                    label: const Text('Continuă cu Facebook'),
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      side: BorderSide(color: Colors.grey[300]!),
                    ),
                  ),

                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text('Nu ai cont? '),
                      TextButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => const RegisterPage(),
                            ),
                          );
                        },
                        child: const Text('Înregistrează-te'),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
