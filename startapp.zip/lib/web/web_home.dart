import 'package:flutter/material.dart';

class WebHome extends StatelessWidget {
  const WebHome({
    super.key,
  });

  static const categories = [
    {
      'name': 'Fashion',
      'icon': Icons.checkroom_outlined,
    },
    {
      'name': 'Încălțăminte',
      'icon': Icons.directions_run_outlined,
    },
    {
      'name': 'Electronice',
      'icon': Icons.devices_outlined,
    },
    {
      'name': 'Gaming',
      'icon': Icons.sports_esports_outlined,
    },
    {
      'name': 'Casă',
      'icon': Icons.home_outlined,
    },
    {
      'name': 'Beauty',
      'icon': Icons.face_retouching_natural_outlined,
    },
    {
      'name': 'Copii',
      'icon': Icons.child_friendly_outlined,
    },
    {
      'name': 'Sport',
      'icon': Icons.sports_soccer_outlined,
    },
  ];

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(
            maxWidth: 1440,
          ),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(
              32,
              32,
              32,
              64,
            ),
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                _buildHero(context),

                const SizedBox(height: 42),

                _buildCategories(context),

                const SizedBox(height: 52),

                _buildSectionHeader(
                  context,
                  title: 'Produse promovate',
                  subtitle:
                      'Descoperă produsele evidențiate de vânzători.',
                ),

                const SizedBox(height: 20),

                _buildProductGrid(context),

                const SizedBox(height: 52),

                _buildSectionHeader(
                  context,
                  title: 'Produse noi',
                  subtitle:
                      'Cele mai recente produse adăugate pe Nexora.',
                ),

                const SizedBox(height: 20),

                _buildProductGrid(context),

                const SizedBox(height: 60),

                _buildSellBanner(context),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHero(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      width: double.infinity,
      constraints: const BoxConstraints(
        minHeight: 300,
      ),
      padding: const EdgeInsets.all(42),
      decoration: BoxDecoration(
        color: theme.colorScheme.primary
            .withOpacity(0.08),
        borderRadius: BorderRadius.circular(28),
        border: Border.all(
          color: theme.colorScheme.primary
              .withOpacity(0.12),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            flex: 6,
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              mainAxisAlignment:
                  MainAxisAlignment.center,
              children: [
                Container(
                  padding:
                      const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 7,
                  ),
                  decoration: BoxDecoration(
                    color: theme
                        .colorScheme
                        .primary
                        .withOpacity(0.10),
                    borderRadius:
                        BorderRadius.circular(30),
                  ),
                  child: Text(
                    'Marketplace-ul Nexora',
                    style: TextStyle(
                      color: theme
                          .colorScheme
                          .primary,
                      fontWeight:
                          FontWeight.w800,
                      fontSize: 13,
                    ),
                  ),
                ),

                const SizedBox(height: 18),

                const Text(
                  'Găsește lucrurile\ncare îți plac.',
                  style: TextStyle(
                    fontSize: 42,
                    height: 1.05,
                    fontWeight:
                        FontWeight.w900,
                    letterSpacing: -1.4,
                  ),
                ),

                const SizedBox(height: 16),

                Text(
                  'Cumpără, vinde și descoperă produse '
                  'de la oameni din comunitatea Nexora.',
                  style: TextStyle(
                    fontSize: 16,
                    height: 1.5,
                    color: theme
                        .colorScheme
                        .onSurface
                        .withOpacity(0.65),
                  ),
                ),

                const SizedBox(height: 26),

                Row(
                  children: [
                    FilledButton.icon(
                      onPressed: () {},
                      icon: const Icon(
                        Icons.search_rounded,
                      ),
                      label: const Text(
                        'Explorează produse',
                      ),
                      style:
                          FilledButton.styleFrom(
                        padding:
                            const EdgeInsets
                                .symmetric(
                          horizontal: 20,
                          vertical: 15,
                        ),
                        shape:
                            RoundedRectangleBorder(
                          borderRadius:
                              BorderRadius.circular(
                            13,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    OutlinedButton.icon(
                      onPressed: () {},
                      icon: const Icon(
                        Icons.add_rounded,
                      ),
                      label: const Text(
                        'Vinde un produs',
                      ),
                      style:
                          OutlinedButton.styleFrom(
                        padding:
                            const EdgeInsets
                                .symmetric(
                          horizontal: 20,
                          vertical: 15,
                        ),
                        shape:
                            RoundedRectangleBorder(
                          borderRadius:
                              BorderRadius.circular(
                            13,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),

          const SizedBox(width: 40),

          Expanded(
            flex: 4,
            child: _buildHeroVisual(context),
          ),
        ],
      ),
    );
  }

  Widget _buildHeroVisual(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      height: 220,
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(
              0.05,
            ),
            blurRadius: 30,
            offset: const Offset(0, 15),
          ),
        ],
      ),
      child: Stack(
        children: [
          Positioned(
            top: 22,
            right: 24,
            child: _floatingIcon(
              context,
              Icons.shopping_bag_outlined,
            ),
          ),
          Positioned(
            bottom: 25,
            left: 28,
            child: _floatingIcon(
              context,
              Icons.favorite_border_rounded,
            ),
          ),
          Positioned(
            right: 90,
            bottom: 30,
            child: _floatingIcon(
              context,
              Icons.local_shipping_outlined,
            ),
          ),
          Center(
            child: Container(
              width: 112,
              height: 112,
              decoration: BoxDecoration(
                color: theme
                    .colorScheme
                    .primary
                    .withOpacity(0.10),
                shape: BoxShape.circle,
              ),
              child: Icon(
                Icons.storefront_rounded,
                size: 58,
                color:
                    theme.colorScheme.primary,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _floatingIcon(
    BuildContext context,
    IconData icon,
  ) {
    final theme = Theme.of(context);

    return Container(
      width: 48,
      height: 48,
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        shape: BoxShape.circle,
        border: Border.all(
          color: theme.dividerColor
              .withOpacity(0.30),
        ),
      ),
      child: Icon(
        icon,
        size: 21,
        color: theme.colorScheme.primary,
      ),
    );
  }

  Widget _buildCategories(BuildContext context) {
    final theme = Theme.of(context);

    return Column(
      crossAxisAlignment:
          CrossAxisAlignment.start,
      children: [
        const Text(
          'Explorează categorii',
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.w900,
            letterSpacing: -0.5,
          ),
        ),

        const SizedBox(height: 18),

        LayoutBuilder(
          builder: (context, constraints) {
            final width =
                constraints.maxWidth;

            final itemWidth =
                (width - 56) / 8;

            return Row(
              children: categories.map(
                (category) {
                  final icon =
                      category['icon']
                          as IconData;

                  return SizedBox(
                    width: itemWidth,
                    child: Padding(
                      padding:
                          const EdgeInsets.only(
                        right: 8,
                      ),
                      child: InkWell(
                        onTap: () {},
                        borderRadius:
                            BorderRadius.circular(
                          18,
                        ),
                        child: Container(
                          padding:
                              const EdgeInsets
                                  .symmetric(
                            vertical: 20,
                            horizontal: 8,
                          ),
                          decoration:
                              BoxDecoration(
                            color: theme
                                .colorScheme
                                .surface,
                            borderRadius:
                                BorderRadius.circular(
                              18,
                            ),
                            border: Border.all(
                              color: theme
                                  .dividerColor
                                  .withOpacity(
                                0.35,
                              ),
                            ),
                          ),
                          child: Column(
                            children: [
                              Icon(
                                icon,
                                size: 29,
                                color: theme
                                    .colorScheme
                                    .primary,
                              ),
                              const SizedBox(
                                height: 10,
                              ),
                              Text(
                                category['name']
                                    as String,
                                maxLines: 1,
                                overflow:
                                    TextOverflow
                                        .ellipsis,
                                textAlign:
                                    TextAlign.center,
                                style:
                                    const TextStyle(
                                  fontSize: 12,
                                  fontWeight:
                                      FontWeight.w700,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ).toList(),
            );
          },
        ),
      ],
    );
  }

  Widget _buildSectionHeader(
    BuildContext context, {
    required String title,
    required String subtitle,
  }) {
    final theme = Theme.of(context);

    return Row(
      crossAxisAlignment:
          CrossAxisAlignment.end,
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment:
                CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(
                  fontSize: 24,
                  fontWeight:
                      FontWeight.w900,
                  letterSpacing: -0.5,
                ),
              ),
              const SizedBox(height: 5),
              Text(
                subtitle,
                style: TextStyle(
                  color: theme
                      .colorScheme
                      .onSurface
                      .withOpacity(0.58),
                ),
              ),
            ],
          ),
        ),
        TextButton(
          onPressed: () {},
          child: const Text(
            'Vezi toate',
          ),
        ),
      ],
    );
  }

  Widget _buildProductGrid(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        int columns = 4;

        if (constraints.maxWidth < 1100) {
          columns = 3;
        }

        final spacing = 18.0;
        final itemWidth =
            (constraints.maxWidth -
                    spacing * (columns - 1)) /
                columns;

        return Wrap(
          spacing: spacing,
          runSpacing: 22,
          children: List.generate(
            8,
            (index) {
              return SizedBox(
                width: itemWidth,
                child: _ProductCard(
                  index: index,
                ),
              );
            },
          ),
        );
      },
    );
  }

  Widget _buildSellBanner(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(30),
      decoration: BoxDecoration(
        color: theme.colorScheme.primary,
        borderRadius: BorderRadius.circular(24),
      ),
      child: Row(
        children: [
          const Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                Text(
                  'Ai ceva de vândut?',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 26,
                    fontWeight:
                        FontWeight.w900,
                  ),
                ),
                SizedBox(height: 8),
                Text(
                  'Publică produsul tău pe Nexora și găsește cumpărători.',
                  style: TextStyle(
                    color: Colors.white70,
                    fontSize: 15,
                  ),
                ),
              ],
            ),
          ),
          FilledButton(
            onPressed: () {},
            style: FilledButton.styleFrom(
              backgroundColor: Colors.white,
              foregroundColor:
                  Colors.black87,
              padding:
                  const EdgeInsets.symmetric(
                horizontal: 24,
                vertical: 15,
              ),
              shape:
                  RoundedRectangleBorder(
                borderRadius:
                    BorderRadius.circular(13),
              ),
            ),
            child: const Text(
              'Începe să vinzi',
              style: TextStyle(
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ProductCard extends StatelessWidget {
  final int index;

  const _ProductCard({
    required this.index,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    final products = [
      ('Produs Nexora', '149 lei'),
      ('Produs nou', '89 lei'),
      ('Articol popular', '199 lei'),
      ('Oferta zilei', '119 lei'),
      ('Produs premium', '299 lei'),
      ('Articol nou', '69 lei'),
      ('Fashion', '159 lei'),
      ('Electronice', '399 lei'),
    ];

    final product =
        products[index % products.length];

    return InkWell(
      onTap: () {},
      borderRadius:
          BorderRadius.circular(18),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          AspectRatio(
            aspectRatio: 1,
            child: Container(
              decoration: BoxDecoration(
                color: theme.colorScheme
                    .onSurface
                    .withOpacity(0.05),
                borderRadius:
                    BorderRadius.circular(18),
              ),
              child: Stack(
                children: [
                  Center(
                    child: Icon(
                      Icons
                          .image_outlined,
                      size: 44,
                      color: theme
                          .colorScheme
                          .onSurface
                          .withOpacity(
                        0.20,
                      ),
                    ),
                  ),
                  Positioned(
                    top: 10,
                    right: 10,
                    child: Container(
                      width: 36,
                      height: 36,
                      decoration:
                          BoxDecoration(
                        color: theme
                            .colorScheme
                            .surface
                            .withOpacity(
                          0.92,
                        ),
                        shape:
                            BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons
                            .favorite_border_rounded,
                        size: 19,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 11),

          Text(
            product.$1,
            maxLines: 1,
            overflow:
                TextOverflow.ellipsis,
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w700,
            ),
          ),

          const SizedBox(height: 4),

          Text(
            product.$2,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w900,
              color:
                  theme.colorScheme.primary,
            ),
          ),
        ],
      ),
    );
  }
}