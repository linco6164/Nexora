import 'package:flutter/material.dart';

class WebShell extends StatefulWidget {
  const WebShell({
    super.key,
  });

  @override
  State<WebShell> createState() => _WebShellState();
}

class _WebShellState extends State<WebShell> {
  int _selectedIndex = 0;

  final List<String> _navigationItems = const [
    'Acasă',
    'Explorează',
    'Mesaje',
    'Comenzi',
    'Profil',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:
          Theme.of(context).scaffoldBackgroundColor,
      body: Column(
        children: [
          _buildHeader(context),
          Expanded(
            child: _buildContent(),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      height: 72,
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        border: Border(
          bottom: BorderSide(
            color: theme.dividerColor.withOpacity(0.25),
          ),
        ),
      ),
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(
            maxWidth: 1440,
          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 32,
            ),
            child: Row(
              children: [
                _buildLogo(context),

                const SizedBox(width: 36),

                Expanded(
                  child: _buildSearch(context),
                ),

                const SizedBox(width: 28),

                _buildHeaderAction(
                  context,
                  icon: Icons.favorite_border_rounded,
                  label: 'Favorite',
                  onTap: () {},
                ),

                _buildHeaderAction(
                  context,
                  icon: Icons.chat_bubble_outline_rounded,
                  label: 'Mesaje',
                  onTap: () {},
                ),

                _buildHeaderAction(
                  context,
                  icon: Icons.notifications_none_rounded,
                  label: 'Notificări',
                  onTap: () {},
                ),

                const SizedBox(width: 12),

                _buildSellButton(context),

                const SizedBox(width: 16),

                _buildProfileButton(context),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildLogo(BuildContext context) {
    final theme = Theme.of(context);

    return InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: () {
        setState(() {
          _selectedIndex = 0;
        });
      },
      child: Padding(
        padding: const EdgeInsets.symmetric(
          vertical: 8,
          horizontal: 4,
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                color: theme.colorScheme.primary,
                borderRadius: BorderRadius.circular(11),
              ),
              child: const Icon(
                Icons.storefront_rounded,
                color: Colors.white,
                size: 21,
              ),
            ),

            const SizedBox(width: 10),

            Text(
              'Nexora',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.w900,
                letterSpacing: -0.7,
                color: theme.colorScheme.onSurface,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSearch(BuildContext context) {
    final theme = Theme.of(context);

    return ConstrainedBox(
      constraints: const BoxConstraints(
        maxWidth: 620,
      ),
      child: TextField(
        decoration: InputDecoration(
          hintText: 'Caută produse, branduri, categorii...',
          prefixIcon: const Icon(
            Icons.search_rounded,
          ),
          filled: true,
          fillColor: theme.colorScheme.onSurface
              .withOpacity(0.045),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none,
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide(
              color: theme.colorScheme.primary,
              width: 1.3,
            ),
          ),
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 16,
            vertical: 14,
          ),
        ),
      ),
    );
  }

  Widget _buildHeaderAction(
    BuildContext context, {
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    final theme = Theme.of(context);

    return Tooltip(
      message: label,
      child: IconButton(
        onPressed: onTap,
        icon: Icon(
          icon,
          size: 23,
        ),
        color: theme.colorScheme.onSurface
            .withOpacity(0.75),
      ),
    );
  }

  Widget _buildSellButton(BuildContext context) {
    final theme = Theme.of(context);

    return FilledButton.icon(
      onPressed: () {
        setState(() {
          _selectedIndex = 5;
        });
      },
      icon: const Icon(
        Icons.add_rounded,
        size: 19,
      ),
      label: const Text(
        'Vinde',
        style: TextStyle(
          fontWeight: FontWeight.w800,
        ),
      ),
      style: FilledButton.styleFrom(
        padding: const EdgeInsets.symmetric(
          horizontal: 18,
          vertical: 14,
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(13),
        ),
        backgroundColor:
            theme.colorScheme.primary,
      ),
    );
  }

  Widget _buildProfileButton(BuildContext context) {
    final theme = Theme.of(context);

    return PopupMenuButton<String>(
      tooltip: 'Cont',
      onSelected: (value) {
        if (value == 'profile') {
          setState(() {
            _selectedIndex = 4;
          });
        }
      },
      itemBuilder: (context) => const [
        PopupMenuItem(
          value: 'profile',
          child: Text('Profil'),
        ),
        PopupMenuItem(
          value: 'settings',
          child: Text('Setări'),
        ),
        PopupMenuItem(
          value: 'logout',
          child: Text('Deconectare'),
        ),
      ],
      child: Container(
        width: 40,
        height: 40,
        decoration: BoxDecoration(
          color: theme.colorScheme.primary
              .withOpacity(0.10),
          shape: BoxShape.circle,
        ),
        child: Icon(
          Icons.person_outline_rounded,
          color: theme.colorScheme.primary,
        ),
      ),
    );
  }

  Widget _buildContent() {
    switch (_selectedIndex) {
      case 0:
        return _buildPlaceholder(
          'Acasă',
          Icons.home_outlined,
        );

      case 1:
        return _buildPlaceholder(
          'Explorează',
          Icons.explore_outlined,
        );

      case 2:
        return _buildPlaceholder(
          'Mesaje',
          Icons.chat_bubble_outline_rounded,
        );

      case 3:
        return _buildPlaceholder(
          'Comenzi',
          Icons.receipt_long_outlined,
        );

      case 4:
        return _buildPlaceholder(
          'Profil',
          Icons.person_outline_rounded,
        );

      case 5:
        return _buildPlaceholder(
          'Vinde',
          Icons.add_circle_outline_rounded,
        );

      default:
        return _buildPlaceholder(
          'Acasă',
          Icons.home_outlined,
        );
    }
  }

  Widget _buildPlaceholder(
    String title,
    IconData icon,
  ) {
    return Center(
      child: Column(
        mainAxisAlignment:
            MainAxisAlignment.center,
        children: [
          Icon(
            icon,
            size: 52,
          ),
          const SizedBox(height: 18),
          Text(
            title,
            style: const TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }
}